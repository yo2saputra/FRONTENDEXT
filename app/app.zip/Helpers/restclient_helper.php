<?php

function akses_restapi($method, $url, $data)
{

    //library CURLrequest
    $client = service('curlrequest');

    // $token = "";

    $headers = [
        // "Authorization" => "Bearer " . $token,
        // "Content-Type" => "application/json",
        "Accept" => "application/json"
    ];

    $response = $client->request($method, $url, ['headers' => $headers, 'http_errors' => false, 'form_params' => $data]);

    return $response->getBody();
}

function akses_restapikey($method, $url, $data = [], $query = [])
{
    $client = service('curlrequest');

    $apiKey = "9F86D081884C7D659A2FEAA0C55AD015A3BF4F1B2B0B822CD15D6C15B0F00A08";
    $headers = [
        "X-API-KEY"     => $apiKey,
        "X-API-Owner"   => "test",
        "Content-Type"  => "application/json",
        "Accept"        => "application/json"
    ];

    $options = [
        "headers" => $headers,
        "http_errors" => false,
        "timeout" => 500,
        "query" => $query
    ];

    if (strtoupper($method) !== 'GET' && strtoupper($method) !== 'DELETE') {
        $options['body'] = json_encode($data);
    }

    try {
        $response = $client->request($method, $url, $options);
        return $response->getBody();
    } catch (\Exception $e) {
        log_message('error', "API Error: " . $e->getMessage());
        return json_encode(['error' => 'Request failed']);
    }
}

function akses_restapikeypdf($method, $url, $data = [], $query = [], $isBinary = false)
{
    $client = service('curlrequest');

    $apiKey = "9F86D081884C7D659A2FEAA0C55AD015A3BF4F1B2B0B822CD15D6C15B0F00A08";
    $headers = [
        "X-API-KEY"     => $apiKey,
        "X-API-Owner"   => "test",
        "Content-Type"  => "application/json",
    ];

    // Jika binary, jangan minta JSON
    if ($isBinary) {
        $headers["Accept"] = "application/pdf, application/octet-stream, */*";
    } else {
        $headers["Accept"] = "application/json";
    }

    $options = [
        "headers" => $headers,
        "http_errors" => false,
        "timeout" => 500,
        "query" => $query
    ];

    if (strtoupper($method) !== 'GET' && strtoupper($method) !== 'DELETE') {
        $options['body'] = json_encode($data);
    }

    try {
        $response = $client->request($method, $url, $options);

        // Jika binary, return raw body tanpa mengubah apapun
        if ($isBinary) {
            return $response->getBody();
        }

        // Jika JSON, return body
        return $response->getBody();
    } catch (\Exception $e) {
        log_message('error', "API Error: " . $e->getMessage());
        return json_encode(['error' => 'Request failed: ' . $e->getMessage()]);
    }
}

function akses_restapikeytoken($method, $url, $data, $apiKey, $token)
{

    //library CURLrequest
    $client = service('curlrequest');

    // API key statis
    $apiKey = ""; //9F86D081884C7D659A2FEAA0C55AD015A3BF4F1B2B0B822CD15D6C15B0F00A08
    // $apiKey = "YOUR_STATIC_API_KEY"; //9F86D081884C7D659A2FEAA0C55AD015A3BF4F1B2B0B822CD15D6C15B0F00A08

    $token = "";

    $headers = [
        "X-API-KEY" => $apiKey, // API Key untuk otorisasi
        "API-Owner"    => "test", // Test
        "Authorization" => "Bearer " . $token,
        "Content-Type" => "application/json",
        "Accept" => "application/json"
    ];

    $response = $client->request($method, $url, ['headers' => $headers, 'http_errors' => false, 'form_params' => $data]);

    return $response->getBody();
}
