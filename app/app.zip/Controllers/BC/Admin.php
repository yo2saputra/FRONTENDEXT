<?php

namespace App\Controllers;

class Admin extends BaseController
{

    public function __construct()
    {
        $session = session();
    }

    // public function index()
    // {
    //     //cek apakah ada session bernama isLogin
    //     if(!$this->session->has('isLogin')){
    //         return redirect()->to('/auth/login');
    //     }

    //     //cek role dari session
    //     if($this->session->get('role') != 1){
    //         return redirect()->to('/user');
    //     }

    //     return view('admin/index');

    // }

    public function index()
    {
        $data = [
            'title' => 'Delta Food | PT. DELTA FOOD DISTRIBUSI'
        ];
        return view('admin/about', $data);
    }
}
