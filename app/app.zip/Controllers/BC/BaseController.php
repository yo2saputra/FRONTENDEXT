<?php

namespace App\Controllers;

use CodeIgniter\Controller;
use CodeIgniter\HTTP\CLIRequest;
use CodeIgniter\HTTP\IncomingRequest;
use CodeIgniter\HTTP\RequestInterface;
use CodeIgniter\HTTP\ResponseInterface;
use Psr\Log\LoggerInterface;
use App\Models\TemplateModel;
use App\Models\DeltafoodModel;

/**
 * Class BaseController
 *
 * BaseController provides a convenient place for loading components
 * and performing functions that are needed by all your controllers.
 * Extend this class in any new controllers:
 *     class Home extends BaseController
 *
 * For security be sure to declare any new methods as protected or private.
 */
abstract class BaseController extends Controller
{
    /**
     * Instance of the main Request object.
     *
     * @var CLIRequest|IncomingRequest
     */
    protected $request;

    /**
     * An array of helpers to be loaded automatically upon
     * class instantiation. These helpers will be available
     * to all other controllers that extend BaseController.
     *
     * @var array
     */
    protected $helpers = [];

    protected $data;
    protected $templateModel;
    protected $deltafoodModel;
    protected $client;
    protected $session;

    /**
     * Be sure to declare properties for any property fetch you initialized.
     * The creation of dynamic property is deprecated in PHP 8.2.
     */
    // protected $session;

    /**
     * Constructor.
     */
    public function initController(RequestInterface $request, ResponseInterface $response, LoggerInterface $logger)
    {
        // Do Not Edit This Line
        parent::initController($request, $response, $logger);

        // Preload any models, libraries, etc, here.

        // E.g.: $this->session = \Config\Services::session();
        $this->session = session();
    }

    public function getTemplateData()
    {
        $this->templateModel = new TemplateModel();
        $this->deltafoodModel = new DeltafoodModel();
        $this->data['template'] = $this->templateModel->getTemplate();
        $this->data['textFooterDeltafood'] = $this->deltafoodModel->getTextFooterDeltafood();

        $this->client = \Config\Services::curlrequest();
        //Set metode request dan endpoint
        $response = $this->client->request('GET', 'https://test-api.jualinternet.com/kontak');
        //Ambil body dari response
        $content = $response->getBody();
        $data['respon_kontak'] = json_decode($content, true);
        $this->data['kontak_api'] = $data['respon_kontak']['kontak'][0];

        //dd($this->data);

        return $this->data;
    }
}
